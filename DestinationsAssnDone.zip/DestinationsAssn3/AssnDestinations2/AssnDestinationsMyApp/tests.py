from django.test import TestCase

# no tests :(