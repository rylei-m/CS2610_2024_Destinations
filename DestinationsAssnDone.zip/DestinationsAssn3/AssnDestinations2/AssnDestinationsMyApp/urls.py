from django.urls import path
from . import views

app_name = 'AssnDestinationsMyApp' 

urlpatterns = [
    path('', views.home, name='home'),
    path('sessions/new', views.new_session, name='new_session'),
    path('users/new', views.new_user, name='new_user'),
    path('register', views.register_user, name='register_user'),
    path('login', views.login_user, name='login_user'),
    path('logout/', views.logout_user, name='logout'),
    path('destinations', views.list_destinations, name='list_destinations'),
    path('destinations/new', views.new_destination, name='new_destination'),
    path('destinations/create', views.create_destination, name='create_destination'),
    path('destinations/<int:id>/edit', views.edit_destination, name='edit_destination'),
    path('destinations/<int:id>/delete', views.destroy_destination, name='destroy_destination'),
    path('sessions/create', views.create_session, name='create_session'),
    path('sessions/destroy', views.destroy_session, name='destroy_session'),

]
